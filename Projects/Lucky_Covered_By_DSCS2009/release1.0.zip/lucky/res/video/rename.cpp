#include <bits/stdc++.h>
#include <windows.h>

using namespace std;

int main() {
	for(int i = 20; i <= 378; i++) {
		string s1 = "video 00_00_00-00_00_30_wpsͼƬ_" + to_string(i) + ".jpg";
		string s2 = to_string(i - 19) + ".jpg";
		string cmd = "ren \"" + s1 + "\" \"" + s2 + "\"";
		cout << cmd << endl;
		system(cmd.c_str());
	}
	return 0;
}

